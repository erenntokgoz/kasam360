const admin = require('firebase-admin');
const path = require('path');
const Debt = require('../models/Debt');
const Tenant = require('../models/Tenant');

// Initialize Firebase Admin using the service account
try {
  const serviceAccountPath = path.resolve(__dirname, '../config/kasam360-firebase-adminsdk.json');
  if (require('fs').existsSync(serviceAccountPath)) {
    admin.initializeApp({
      credential: admin.credential.cert(require(serviceAccountPath))
    });
    console.log('[NotificationService] Firebase Admin initialized.');
  } else {
    console.warn('[NotificationService] Firebase config missing. Notifications will be logged only.');
  }
} catch (error) {
  console.error('[NotificationService] Firebase Admin initialization error:', error);
}

/**
 * Send Push Notification
 */
const sendPushNotification = async (deviceToken, title, body, data = {}) => {
  try {
    if (!deviceToken) return false;
    
    console.log(`[NotificationService] Sending Push to [${deviceToken}] - ${title}`);
    
    if (admin.apps.length > 0) {
      const message = {
        notification: { title, body },
        data: { ...data, click_action: 'FLUTTER_NOTIFICATION_CLICK' },
        token: deviceToken
      };
      await admin.messaging().send(message);
    }
    return true;
  } catch (error) {
    console.error('[NotificationService] Error sending notification:', error);
    return false;
  }
};

/**
 * Checks for debts due in 24 hours and notifies tenants
 */
const checkAndNotifyDueDebts = async () => {
  try {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(23, 59, 59, 999);

    const debts = await Debt.find({
      status: { $in: ['PENDING', 'PARTIAL'] },
      dueDate: { $lte: tomorrow, $gte: new Date() },
      isDeleted: false
    }).populate('tenantId');

    for (const debt of debts) {
      // Find tenant's device token (Assuming we store it on Tenant or a new UserDevice model)
      const tenant = await Tenant.findById(debt.tenantId);
      if (tenant && tenant.deviceToken) {
        const title = 'Ödeme Hatırlatması';
        const body = `${debt.entityName} için ${debt.type === 'GIVEN' ? 'alacak' : 'borç'} vadesi yaklaşıyor.`;
        await sendPushNotification(tenant.deviceToken, title, body, { debtId: debt._id.toString() });
      }
    }
  } catch (error) {
    console.error('[NotificationService] Error in checkAndNotifyDueDebts:', error);
  }
};

module.exports = {
  sendPushNotification,
  checkAndNotifyDueDebts
};
